
soma = 0

for i in range(15, 101, 1):
    soma += i
    print(f'{i}')
    
print(f'\nO resultado do somatório: {soma}\n')

